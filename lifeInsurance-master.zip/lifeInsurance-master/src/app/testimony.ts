export interface Testimony {

  id: number; name: string; designation: string;
    relationship: string;
  comment: string;
}
