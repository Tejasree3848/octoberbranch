export interface PolicyDetail {
  id: number;
   policyHolderName: string;
    policyAmount: number;
     maturityDate: Date; }


