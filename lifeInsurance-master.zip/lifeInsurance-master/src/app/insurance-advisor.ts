export interface InsuranceAdvisor {
  id: number; name: string; mobileNumber: number;
}
