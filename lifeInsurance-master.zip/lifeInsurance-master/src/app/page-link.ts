export interface PageLink {
  linkText: string; linkStyle: string; linkRef?: string;
}
