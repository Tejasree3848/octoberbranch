import { AddElementDirective } from './add-element.directive';

describe('AddElementDirective', () => {
  it('should create an instance', () => {
    const directive = new AddElementDirective();
    expect(directive).toBeTruthy();
  });
});
