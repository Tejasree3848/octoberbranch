export interface Policy {
  policyName: string; description: string;
}
