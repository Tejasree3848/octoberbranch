import { HighLightDirective } from './high-light.directive';

describe('HighLightDirective', () => {
  it('should create an instance', () => {
    const directive = new HighLightDirective();
    expect(directive).toBeTruthy();
  });
});
